#!/bin/bash

python SI2_DMPNN.py
python SI2_DMPNN_plot_file.py